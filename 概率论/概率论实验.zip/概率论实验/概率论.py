import numpy as np

# 设置随机数种子
np.random.seed(42)

# 模拟单个学生家长参会人数
def simulate_single_student() -> int:
    p = [0.05, 0.8, 0.15]
    return np.random.choice([0, 1, 2], p=p)

# 模拟400个学生家长参会总人数
def simulate_total_parents() -> int:
    return np.sum(np.random.choice([0, 1, 2], size=400, p=[0.05, 0.8, 0.15]))

# 模拟一名家长来参加会议的学生人数
def simulate_single_parent_students() -> int:
    return np.sum(np.random.choice([0, 1, 2], size=400, p=[0.05, 0.8, 0.15]) == 1)

# 模拟多次计算概率
def simulate_probabilities(num_simulations: int) -> tuple:
    total_parents_greater_450_count = 0
    single_parent_students_greater_340_count = 0
    for _ in range(num_simulations):
        total_parents = simulate_total_parents()
        single_parent_students = simulate_single_parent_students()
        if total_parents > 450:
            total_parents_greater_450_count += 1
        if single_parent_students >= 340:
            single_parent_students_greater_340_count += 1
    return (total_parents_greater_450_count / num_simulations, 
            single_parent_students_greater_340_count / num_simulations)

probability_total_parents, probability_single_parent_students = simulate_probabilities(10000)
print("模拟的参加会议的家长人数超过450的概率:", probability_total_parents)
print("模拟的一名家长来参加会议的学生人数不少于340的概率:", probability_single_parent_students)